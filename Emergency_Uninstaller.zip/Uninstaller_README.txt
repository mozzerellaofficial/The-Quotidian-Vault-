=========================================================
THE QUOTIDIAN VAULT - EMERGENCY UNINSTALLER
=========================================================

Thank you for using The Quotidian Vault. 

If you are experiencing issues uninstalling a previous version, 
or if Windows is blocking the built-in uninstaller, you can use 
this tool to cleanly wipe the app from your system.

---------------------------------------------------------
HOW TO RUN THIS SCRIPT (IF BLOCKED BY WINDOWS)
---------------------------------------------------------
Because this is a powerful cleanup script, Windows "Smart App Control" 
or "SmartScreen" may block it from running.

To bypass this and run the uninstaller:
1. Right-click the "emergency-uninstaller.bat" file.
2. Select "Properties" from the menu.
3. At the bottom of the General tab, check the box that says "Unblock".
4. Click Apply, then OK.
5. Double-click the .bat file to run it!

---------------------------------------------------------
TERMS AND CONDITIONS
---------------------------------------------------------
By opening and executing the "emergency-uninstaller.bat" file, 
you acknowledge and agree to the following:
1. You understand this script will forcefully close all active 
   Quotidian Vault processes.
2. This script will permanently delete the installation files 
   and local data directories associated with the application.
3. The developers are not responsible for any data loss that 
   may occur. Please ensure your encrypted vaults are safely 
   backed up elsewhere if you plan to keep them.
